#include <Arduino.h>
#include <SoftwareSerial.h>
#include <Messaging.h>
#include <ExpirationTimer.h>

SoftwareSerial mySerial = SoftwareSerial(10, 11);
String rd;
String reset;

unsigned long lastTime;

const int REDLED = 2;
const int YELLED = 3;
const int GRELED = 4;

enum LIGHTSTATE
{
  INIT,
  RED_LIGHT,
  YELLOW_LIGHT,
  GREEN_LIGHT,
  WAIT
};

bool TimerElapsed(unsigned int timeout)
{
  return millis() - lastTime >= timeout;
}

void TimerReset()
{
  lastTime = millis();
}

void setup()
{
  pinMode(10, INPUT);
  pinMode(11, OUTPUT);
  pinMode(REDLED, OUTPUT);
  pinMode(YELLED, OUTPUT);
  pinMode(GRELED, OUTPUT);
  Serial.begin(9600);
  mySerial.begin(9600);
}

LIGHTSTATE state = INIT;

void loop()
{
  if (mySerial.available() > 0)
  {
    rd = mySerial.readStringUntil(';');
    if (rd == "GREEN")
    {
      TimerReset();
      state = GREEN_LIGHT;
    }
    Serial.println(rd);
  }

  switch (state)
  {
  case INIT:
    lastTime = millis();
    state = RED_LIGHT;
    break;
  case RED_LIGHT:
  {
    digitalWrite(YELLED, LOW);
    digitalWrite(GRELED, LOW);
    digitalWrite(REDLED, HIGH);

    mySerial.print("GREEN;");
    state = WAIT;
    break;
  }
  case GREEN_LIGHT:
  {
    digitalWrite(REDLED, LOW);
    digitalWrite(YELLED, LOW);
    digitalWrite(GRELED, HIGH);

    if (TimerElapsed(5000))
    {
      TimerReset();
      state = YELLOW_LIGHT;
    }

    break;
  }
  case YELLOW_LIGHT:
  {
    digitalWrite(REDLED, LOW);
    digitalWrite(GRELED, LOW);
    digitalWrite(YELLED, HIGH);
    if (TimerElapsed(2000))
    {
      TimerReset();

      state = RED_LIGHT;
    }

    break;
  }
  case WAIT:
  {
    break;
  }
  default:
    break;
  }
}
